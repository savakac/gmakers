﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Projekt_dioda1
{
    public struct Bod
    {
        public double px;
        public double rx;
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void grafPaintT(PaintEventArgs e)
        {
             // Create pen.
            Pen yellowPen = new Pen(Color.Yellow, 3);

            // Create points that define polygon.
            Point point1 = new Point(350, 100);
            Point point2 = new Point(360, 90);
            Point point3 = new Point(370, 100);
            Point point4 = new Point(380, 110);
            Point point5 = new Point(390, 100);
            Point point6 = new Point(400, 90);
            Point point7 = new Point(410, 100);
            Point point8 = new Point(420, 110);
            Point point9 = new Point(430, 100);
            Point point10 = new Point(440, 90);

            Point[] curvePoints = 
            {
                point1,
                point2,
                point3,
                point4,
                point5,
                point6,
                point7,
                point8,
                point9,
                point10
            };

            // Draw polygon to screan.
            e.Graphics.DrawPolygon(yellowPen, curvePoints);
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            const double K = 1.38E-23;
            const double E = 1.60E-19;
            // Inicializacia grafickych ovladacov.
            Graphics g = e.Graphics;

            Pen blackPen = new Pen(Color.Black, 2);
            Point pointX1 = new Point(0, 100); // Zaciatocny bod vzdialenost od left, top.
            Point pointX2 = new Point(700, 100); // Koncovy bod vzdialenost od point1, top.
            g.DrawLine(blackPen, pointX1, pointX2);
            Point pointY1 = new Point(350, 0);
            Point pointY2 = new Point(350, 200);
            g.DrawLine(blackPen, pointY1, pointY2);

            // Vykreslenie risiek x 100 dielikov 1V.
            g.DrawLine(blackPen, 50, 95, 50, 105);
            g.DrawLine(blackPen, 150, 95, 150, 105);
            g.DrawLine(blackPen, 250, 95, 250, 105);
            g.DrawLine(blackPen, 450, 95, 450, 105);
            g.DrawLine(blackPen, 550, 95, 550, 105);
            g.DrawLine(blackPen, 650, 95, 650, 105);

            // Vykreslenie risiek y 100 dielikov 1A.
            g.DrawLine(blackPen, 345, 0, 355, 0);
            g.DrawLine(blackPen, 345, 200, 355, 200);

            // Vykreslenie mriezky zvisle.
            Pen grayPen1 = new Pen(Color.Gray, 1);
            for (int i = 10; i <= 700; )
            {
                g.DrawLine(grayPen1, i, 0, i, 200);
                i += 10;
            }
            // Vykreslenie mriezky vodorovne.
            for (int i = 10; i <= 200; )
            {
                g.DrawLine(grayPen1, 0, i, 700, i);
                i += 10;
            }

            // Vykreslenie Y.
            String drawStringY = "I [A]";
            Font DrawFontY = new Font("Ariel", 16);
            SolidBrush drawBrushY = new SolidBrush(Color.Blue);
            PointF drawPointY = new PointF(300, 0);
            g.DrawString(drawStringY, DrawFontY, drawBrushY, drawPointY);

            // Vykresenie X.
            String drawStringX = "U [V]";
            Font drawFontX = new Font("Ariel", 16);
            SolidBrush drawBrushX = new SolidBrush(Color.Blue);
            PointF drawPointX = new PointF(650, 110);
            g.DrawString(drawStringX, drawFontX, drawBrushX, drawPointX);

            // Stred suradnicovej sustay 350 x, 100y
            // Vykreslenie krivky.
            Pen redPen = new Pen(Color.Red, 1);
            //g.DrawLine(redPen, 350, trackBar2.Value, trackBar1.Value, 100); // Left, top, right, botton.
            
            // Vykreslenie napatia.
            Pen bluePenU = new Pen(Color.Blue, 1);
            Point uA = new Point(((trackBar3.Value + 175) * 2), 0);
            Point uB = new Point(((trackBar3.Value + 175) * 2), 200);
            String drawStringUV = "U = " + textBox2.Text + " V";
            Font drawFontUV = new Font("Veradana", 10);
            SolidBrush drawBrushUV = new SolidBrush(Color.Blue);
            PointF drawPointUV = new PointF(((trackBar3.Value + 180) * 2), 30);

            g.DrawString(drawStringUV, drawFontUV, drawBrushUV, drawPointUV);
            g.DrawLine(bluePenU, uA, uB);

            //label9.Text = uA.X.ToString();

            // Prepocitanie suradnicovej sustavy os x do typu Point.
            Point[] xNum = new Point[701];
            for (int i = 0; i <= 700; i++)
            {
                xNum[i] = new Point();
                xNum[i].X = i;
                xNum[i].Y = -350 + i;
            }

            // Prepocitanie suradnicovej sustavy os y do typu Point.
            Point[] yNum = new Point[201];
            for (int i = 0; i <= 200; i++)
            {
                yNum[i] = new Point();
                yNum[i].X = i;
                yNum[i].Y = 100 - i;
            }

            // Prepocitanie suradnicovej sustavy do struktury Bod os x.
            double osX = -1.75;
            Bod[] xVal = new Bod[701];
            for (int i = 0; i <= 700; i++)
            {
                xVal[i] = new Bod();
                xVal[i].px = i;
                xVal[i].rx = osX + 0.005;
                osX += 0.005;
            }

            // Prepocitanie suradnicovej sustavy do struktury Bod os y.
            Bod[] yVal = new Bod[201];
            for (int i = 0; i <= 200; i++)
            {
                yVal[i] = new Bod();
                yVal[i].px = i;
                yVal[i].rx = 100 - (i * 0.005);
            }

                try
                {
                    for (int i = 0; i <= 700; i++)
                    {
                        // Vypocitanie I diody.
                        // k boltzmanova konstanta 1.38E-23.
                        // Si 2 nefunguje bezna hodnota 0.026V.
                        // Povodna hodnota 300000 neskor nahradene trackBar2.
                        // Nasobene 0.0000000001 koli double hodnote trackBar2.Value.
                        double xPointA = ((trackBar2.Value * 0.00000001) * (Math.Exp((xVal[i].rx) / ((K * (trackBar1.Value * 0.01)) / (E))) - 1)) * 10000;
                        double xPointB = ((trackBar2.Value * 0.00000001) * (Math.Exp((xVal[i + 1].rx) / ((K * (trackBar1.Value * 0.01)) / (E))) - 1)) * 10000;
                        int cXPointA = Convert.ToInt32(xPointA);
                        int cXPointB = Convert.ToInt32(xPointB);

                        //label9.Text = ((K * (trackBar1.Value * 0.01)) / 1.6E-19).ToString("0.0000000");
                        //label10.Text = (trackBar1.Value * 0.01).ToString("0.00");
                        label9.Text = yVal[0].rx.ToString("0.000");
                        Point a = new Point(i, (100 - cXPointA));
                        Point b = new Point(i + 1, (100 - cXPointB));

                        g.DrawLine(redPen, a, b);
                    }
                }
                catch
                {
                    return;
                }
            
            // Vykreslenie funkcie sinus.
            /*try
            {
                for (int i = 0; i <= 700; i++)
                {
                    // Vypocet sinusu a zaokruhlenie.
                    double koeficient = trackBar1.Value;
                    double xsa = (Math.Sin((0.05)*xNum[i].Y) * koeficient);
                    double xsb = (Math.Sin((0.05)*xNum[i + 1].Y) * koeficient);
                    int cxsa = Convert.ToInt32(xsa);
                    int cxsb = Convert.ToInt32(xsb);

                    Point a = new Point(i, (100 - cxsa));
                    Point b = new Point(i + 1, (100 - cxsb));

                    g.DrawLine(redPen, a, b);
                }

                //label11.Text = Convert.ToInt32(100 - (Math.Sin(xNum[5].Y) * 10)).ToString();
            }
            catch 
            {
                return;
            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Zatvorenie projektu
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //double tracVal = Convert.ToDouble(textBox2.Text);
            //trackBar3.Value = Convert.ToInt32(tracVal * 100);
            //pictureBox1.Invalidate();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //trackBar2.Value = Int32.Parse(textBox1.Text);
            //pictureBox1.Invalidate();
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = (trackBar3.Value * 0.01).ToString("0.00");
            // Prekreslenie obrazovky.
            pictureBox1.Invalidate();
            //pictureBox1.Refresh();
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = (trackBar2.Value * 0.000000001).ToString("0.000000");
            pictureBox1.Invalidate();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            int xSuradnica = e.X - 350;
            int ySuradnica = 100 - e.Y;
            label5.Text = (xSuradnica * 0.005).ToString("0.00") + "V";
            label6.Text = (ySuradnica * 0.005).ToString("0.00") + "A";
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox3.Text = (trackBar1.Value * 0.01).ToString("0.00");
            //label9.Text = (trackBar1.Value * 0.001).ToString("0.000");
            pictureBox1.Invalidate();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
