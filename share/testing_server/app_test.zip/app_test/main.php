<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Cestovatelsky festival test</title>

	<link rel="shortcut icon" href="image/icon.png"> <!--Iconka stranky-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <!--Nastavenie kodovania stranky-->
	<meta name="author" content="Jan Salva"> <!--Autor stranky-->
	<meta name="keywords" content="Cestovatelsky festival"> <!--Klucove slova-->
	<meta name="description" content="Cestovatelsky festival"> <!--Popis stranky-->

	<link rel="stylesheet" type="text/css" href="style/main.css"> <!--Prilinkovanie externeho suboru so stylmi-->

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="jsc/main.js"></script>

</head>
<body class="ShowView">

	<div class="Header">
		<div class="HeaderLogo">Logo</div>
	</div>
	
	<div class="Slidebox">

	</div>

	<div class="Content">
		<div class="EventPanel">
			<div class="BoxLeft"><p>KALENDÁR AKCIÍ</p></div>
			<div class="Box"><p>AKTUALITY</p></div>
			<div class="Box"><p>FESTIVAL CESTOU NECESTOU</p></div>
			<div class="Box"><p>PREDNÁŠKY</p></div>
			<div class="BoxRight"><p>PREDNÁŠAJÚCI</p></div>
		</div>

	</div>

	<div class="Foot">
		<div class="Square">
			<div class="SquareIn"><p>NAVIGÁCIA</p></div>
			<div class="SquareIn"><p>ARCHÍV</p></div>
			<div class="SquareIn"><p>CESTOU NECESTOU</p></div>
			<div class="SquareIn"><p>KONTAKT</p></div>
		</div>
	</div>

</body>
</html>